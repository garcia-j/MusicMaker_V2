Design Changes from Assignment 6:
* Model interface now parameterizes across classes instead of using specific classes.
* getNotes method returns a Map instead of a SortedMap.
* getHighPitch and getLowPitch methods were added that get the highest and lowest pitches of a model.
* The getState method was moved to the ConsoleView.
* Tests were added for new getter methods.
* Fixed the Javadoc for the model implementation and model operations so they are more informative.
* Added a version of the model that is Read Only. The Read Only version contains a non-ReadOnly model. For methods that would change the data, an UnsupportedOperationException is thrown. For methods that get data, dispatch is used on the model class variable.
* Added tests for the ReadOnly model.

Controller:
* Added a Music Editor controller. This controller has one method “go” which starts the application.
* A KeyboardListener class was created to allow the controller to listen for key presses.
* The controller implementation contains an IView (more on that later), a MusicEditorOperations, and an int that represents the current beat being played.
* When the controller implementation is started via the go method, it first determines if the KeyboardListener is needed. If it is, it configures the KeyboardListener. The display method is then called and the view is displayed to the console.
* The configureKeyBoardListener method sets up the maps that contain the Runnables that need to be called when a certain key is typed, pressed or released. Two Runnable implementations were created that decrement the current beat if the left arrow is pressed or increment the current beat if the right arrow is pressed.

Views:
* The IView interface has one method, which is used to display the view given a model. The interface is parameterized across the Music Editor model.

Console View:
* The console view is equivalent to the getState method. The code from the model was copied over. The view class has an Appendable which is used to output to the console.
* The console view takes the model that is passed into it in the display method and prints out the notes such that the beat number is printed from top to bottom increasing on the left side and pitches are printed at the top of the screen in increasing pitch. The notes are printed downward and the head of a note is marked as an “X” while the continuation of a note is marked as an “|”.

Midi View:
* Contains a sequencer that is used to play a track.
* The display function gets all the notes from the model passed in and converts the model to ShortMessages for the instrument, the start of the note and the stop of the note. These ShortMessages are converted to MidiEvents using a Factor constant set at the beginning of the class. The MidiEvents are then added to the track. Once all the notes are added to the track, the sequencer is started, the tempo is set, and the thread is put to sleep for the duration of the song such that the sequencer does not close before it is over. Once the song is over the sequencer closes and the Application closes via System.exit.
* The private method in the class converts the pitch from the model to the corresponding Midi value.

Gui View:
* GuiView is an interface that uses methods that are only used for the GuiView.
* The methods are:
  * initialize - initializes the view to set it visible
  * addKeyListener - adds the given KeyListener to the view
  * getPreferredSize - sets the size of the Gui View
  * updateCurrentBeat - updates the current beat being played

GuiViewFrame:
* Implementation of GuiView interface. GuiViewFrame keeps track of a JScrollPane, a ScorePanel, a KeyboardPanel, and a model.
* The JScrollPane contains the ScorePanel and is used to scroll when the ScorePanel is too large.
* The ScorePanel is a JPanel that shows the notes in score format (more on that below).
* The KeyboardPanel is a JPanel that shows the current keys that are being played on a virtual keyboard (more on that below).
* The model is a ReadOnly Music Editor model that contains all the data of the Music Editor.
* The constructor for GuiViewFrame creates all the necessary Components and sets the layout of the Frame. A GridLayout with 2 rows and 1 column was used.
* The ScorePanel is added to the top of the GridLayout and the KeyboardPanel is added to the bottom of the GridLayout.
* In the display method the model in this class is set and the ScorePanel size is adjusted based on the notes. The JScrollPane is adjusted with the new ScorePanel and the KeyboardPanel is also adjusted.
* The addKeyListener method sets the passed in key listener as this view’s KeyListener.
* The initialize method sets the view to visible.
* The getPreferredSize method sets the dimensions of the view to two constants declared at the top of the class.
* The updateCurrentBeat method is used to update the Keyboard and Score Panels current beat. This moves the red line of the ScorePanel and changes the orange keys of the KeyboardPanel when the repaint method is called.

ScorePanel:
* Extends JPanel
* This class has two class variables a ReadOnly Music Editor model and an int currentBeat.
* The updateValues method updates the class model and currentBeat.
* The paintComponent method paints the actual music score. The pitches of the model are printed in decreasing pitch along the left side. The beat is printed across the top of the screen in increasing order by 4. The notes are printed as squares where a square represents one beat. The start of a note is represented by a black square and the continuation of a note is represented by a green square.

KeyboardPanel:
* Extends JPanel
* This class also has two class variables a ReadOnly Music Editor model and an int currentBeat.
* The updateValues method updates the class model and the currentBeat.
* The paintComponent method paints the ten octave keyboard. The pitches of the notes being played are colored orange.
* A private method pitchToKey is used to convert a pitch to its key number where the first piano key is 0, the second key is 1, etc.
* Two private methods are used to get the right value to add to convert the key number (black and white keys) to the white key number or the black key number.

Composition Builder:
* This Builder class was added to MusicEditorModelImpl to build compositions based on Midi input.
* The class has three variables a map that maps the note number to the MusicNote, the tempo, and a static int that keeps track of the current note being added. A HashMap was used because mappings can be accessed more efficiently than a List.
* The class has methods to set a tempo, add a note, and create a composition.

MusicReader:
* This class was provided for us. It reads notes from a Midi text file in and creates a Music Editor model from it.

ViewFactory:
* Class to create the correct view based on String input. A String of “console” creates a ConsoleView, a String of “visual” creates a GuiViewFrame, and a String of “midi” creates a MidiViewImpl. 

MusicEditor:
* The main method takes in two String arguments, a fileName and the type of view.
* A model and a view are created.
* The filename is checked to make sure that it is a valid file name.
* ViewFactory is created to get the right view and send it to the controller along with the model.
* The controller is started.

MockSequencer:
* Class to mock a sequencer so we could test our MidiView.
* Implements Sequencer so we can pass it to our MidiView.
* We decided to override the setSequence method to output messages to a log when a note was added.
* Using this log we were able to test that the correct notes were added to the Midi.