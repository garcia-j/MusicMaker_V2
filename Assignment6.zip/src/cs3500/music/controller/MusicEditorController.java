package cs3500.music.controller;

import java.awt.event.KeyEvent;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import cs3500.music.model.MusicEditorModelImplReadOnly;
import cs3500.music.model.MusicEditorOperations;
import cs3500.music.model.MusicNote;
import cs3500.music.model.Pitch;
import cs3500.music.view.GuiView;
import cs3500.music.view.IView;

/**
 * Controller for the Music Editor. Controls an IView, a Music Editor model and a current beat. As
 * the current beat or model changes, it sends the command to change to the view to update.
 */
public class MusicEditorController implements IController {
  private IView view; // The view of the Music Editor
  private MusicEditorOperations<MusicNote, Pitch> model; // The Music Editor model
  private int currentBeat; // The current beat being played

  /**
   * Constructor for the controller. Takes in a view and a model. Sets the default currentBeat to 0.
   *
   * @param view The Music Editor view
   * @param model The Music Editor model
   */
  public MusicEditorController(IView view, MusicEditorOperations model) {
    this.view = view;
    this.model = model;
    currentBeat = 0;
  }

  @Override
  public void startApplication() {
    if (view instanceof GuiView) {
      configureKeyBoardListener();
    }
    view.display(new MusicEditorModelImplReadOnly(this.model));
  }

  /**
   * Configures the Keyboard Listener for the controller by creating three maps containing
   * Runnables.
   */
  private void configureKeyBoardListener() {
    Map<Character, Runnable> keyTypes = new HashMap<>();
    Map<Integer, Runnable> keyPresses = new HashMap<>();
    Map<Integer, Runnable> keyReleases = new HashMap<>();

    keyPresses.put(KeyEvent.VK_LEFT, new MoveLeft());
    keyPresses.put(KeyEvent.VK_RIGHT, new MoveRight());

    KeyboardListener keyboardListener = new KeyboardListener();
    keyboardListener.setKeyTypedMap(keyTypes);
    keyboardListener.setKeyPressedMap(keyPresses);
    keyboardListener.setKeyReleasedMap(keyReleases);

    GuiView guiView = (GuiView) view;

    guiView.addKeyListener(keyboardListener);
  }

  /**
   * Runnable to decrement the current beat when the left arrow is pressed.
   */
  class MoveLeft implements Runnable {
    public void run() {
      if (currentBeat != 0) {
        currentBeat--;
        GuiView guiView = (GuiView) view;
        guiView.updateCurrentBeat(currentBeat);
      }
    }
  }

  /**
   * Runnable to increment the current beat when the right arrow is pressed.
   */
  class MoveRight implements Runnable {
    public void run() {
      if (currentBeat != Collections.max(model.getNotes().keySet()) + 1) {
        currentBeat++;
        GuiView guiView = (GuiView) view;
        guiView.updateCurrentBeat(currentBeat);
      }
    }
  }

}
