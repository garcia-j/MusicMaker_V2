package cs3500.music.view;

import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.sound.midi.MidiEvent;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.sound.midi.ShortMessage;
import javax.sound.midi.Synthesizer;
import javax.sound.midi.Track;
import javax.sound.midi.Receiver;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.MidiChannel;

import cs3500.music.model.MusicEditorModelImplReadOnly;
import cs3500.music.model.MusicNote;
import cs3500.music.model.NoteName;
import cs3500.music.model.Pitch;

/**
 * The Midi View for a Music Editor. When displayed, the Midi converts notes to their Midi
 * equivalent and then adds each note to a sequencer. Once all notes are added to the sequencer,
 * the notes are played to the user.
 */
public class MidiViewImpl implements IView<MusicEditorModelImplReadOnly> {
  public static final int FACTOR = 7; // Factor used for resolution and tick multiplication

  /**
   * The sequencer that contains the notes of the Music Editor.
   */
  private final Sequencer sequencer;

  /**
   * Constructor for the MidiView. Creates a new Sequencer.
   */
  public MidiViewImpl() {
    Sequencer seq = null;
    try {
      seq = MidiSystem.getSequencer();
      seq.open();
    } catch (MidiUnavailableException e) {
      e.printStackTrace();
    }

    this.sequencer = seq;
  }

  /**
   * Ease of use constructor for the MidiView.
   */
  public MidiViewImpl(Sequencer sequencer) {
    this.sequencer = sequencer;
  }


  /**
   * Relevant classes and methods from the javax.sound.midi library:
   * <ul>
   *  <li>{@link MidiSystem#getSynthesizer()}</li>
   *  <li>{@link Synthesizer}
   *    <ul>
   *      <li>{@link Synthesizer#open()}</li>
   *      <li>{@link Synthesizer#getReceiver()}</li>
   *      <li>{@link Synthesizer#getChannels()}</li>
   *    </ul>
   *  </li>
   *  <li>{@link Receiver}
   *    <ul>
   *      <li>{@link Receiver#send(MidiMessage, long)}</li>
   *      <li>{@link Receiver#close()}</li>
   *    </ul>
   *  </li>
   *  <li>{@link MidiMessage}</li>
   *  <li>{@link ShortMessage}</li>
   *  <li>{@link MidiChannel}
   *    <ul>
   *      <li>{@link MidiChannel#getProgram()}</li>
   *      <li>{@link MidiChannel#programChange(int)}</li>
   *    </ul>
   *  </li>
   * </ul>
   * @see <a href="https://en.wikipedia.org/wiki/General_MIDI">
   *   https://en.wikipedia.org/wiki/General_MIDI
   *   </a>
   */
  @Override
  public void display(MusicEditorModelImplReadOnly model) {
    Set<MusicNote> allNotes = new HashSet<MusicNote>();
    int tempo;

    try {
      Sequence sequence = new Sequence(Sequence.PPQ, FACTOR);
      Track track = sequence.createTrack();

      tempo = model.getTempo();
      Map<Integer, Set<MusicNote>> notes = model.getNotes();

      for (Integer i : notes.keySet()) {
        for (MusicNote n : notes.get(i)) {
          allNotes.add(n);
        }
      }

      for (MusicNote n : allNotes) {
        ShortMessage start = new ShortMessage(ShortMessage.NOTE_ON, 0, pitchToMIDI(n.getPitch()),
                n.getVolume());
        ShortMessage stop = new ShortMessage(ShortMessage.NOTE_OFF, 0, pitchToMIDI(n.getPitch()),
                n.getVolume());
        ShortMessage instrument = new ShortMessage(ShortMessage.PROGRAM_CHANGE, 0,
                n.getInstrument(), 0);

        MidiEvent instrumentEvent = new MidiEvent(instrument, n.getStartBeat() * FACTOR);
        track.add(instrumentEvent);

        MidiEvent startEvent = new MidiEvent(start, n.getStartBeat() * FACTOR);
        track.add(startEvent);

        MidiEvent stopEvent = new MidiEvent(stop,
                (n.getStartBeat() + n.getDuration()) * FACTOR - 1);
        track.add(stopEvent);
      }

      this.sequencer.setSequence(sequence);
    } catch (Exception e) {
      return;
    }

    sequencer.start();
    sequencer.setTempoInMPQ(tempo);

    try {
      Thread.sleep(Collections.max(model.getNotes().keySet()) * tempo / 1000);
    } catch (Exception e) {
      return;
    }
    this.sequencer.close();

    if (!(sequencer instanceof MockSequencer)) {
      System.exit(0);
    }
  }

  /**
   * Converts a pitch to its corresponding MIDI value.
   *
   * @param p The pitch to convert
   * @return The MIDI value
   */
  private int pitchToMIDI(Pitch p) {
    NoteName noteName = p.getNoteName();
    int octave = p.getOctave();
    int octaveMIDI = (octave + 1) * 12;

    return octaveMIDI + noteName.ordinal();
  }
}
