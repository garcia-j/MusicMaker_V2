package cs3500.music.view;

import java.awt.Dimension;
import java.awt.event.KeyListener;

/**
 * Represents a GUI View for a Music Editor. A GuiView is a view where the user can see the
 * notes represented as shapes and other images.
 */
public interface GuiView<T> extends IView<T> {

  /**
   * Initializes the GuiView and makes the view visible.
   */
  void initialize();

  /**
   * Adds a KeyListener to this view.
   *
   * @param listener The KeyListener to add
   */
  void addKeyListener(KeyListener listener);

  /**
   * Sets the size of this view.
   *
   * @return The size of the view.
   */
  Dimension getPreferredSize();

  /**
   * Updates the current beat of the GuiView.
   *
   * @param currentBeat The current beat to update to
   */
  void updateCurrentBeat(int currentBeat);
}
