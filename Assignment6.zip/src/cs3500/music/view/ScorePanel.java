package cs3500.music.view;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.Font;
import java.awt.BasicStroke;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.JPanel;

import cs3500.music.model.MusicEditorModelImplReadOnly;
import cs3500.music.model.MusicNote;
import cs3500.music.model.Pitch;

/**
 * Represents a score of a Music Editor. The score section displays the notes in the Music Editor
 * on the left side in a range from the lowest to highest pitch, with the highest pitch at the top
 * of the left side. It displays the beats in the Music Editor along the top of the score section
 * with each beat number corresponding to four beats in the Music Editor. A start beat of a note is
 * represented by a black square while a continuation beat of a note is represented by a green
 * square. The current beat of the Music Editor is represented by a red line and moves based on user
 * input.
 */
public class ScorePanel extends JPanel implements IGuiPanel<MusicEditorModelImplReadOnly> {
  private static final int NOTE_DIMENSION = 15; // The height and width of a note
  private static final int X_OFFSET = 50; // The offset in the y direction
  private static final int Y_OFFSET = 10; // The offset in the x direction

  // The model containing the notes of the editor
  private MusicEditorModelImplReadOnly model;

  // The current beat being played
  private int currentBeat;

  /**
   * Constructor for ScorePanel. Sets the model to a new ReadOnly model and the current beat being
   * played to 0.
   */
  public ScorePanel() {
    this.model = new MusicEditorModelImplReadOnly();
    this.currentBeat = 0;
  }

  @Override
  public void updateValues(MusicEditorModelImplReadOnly model, int currentBeat) {
    this.model = model;
    this.currentBeat = currentBeat;
  }

  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);

    Graphics2D graphics2D = (Graphics2D)g;
    TreeMap<Integer, Set<MusicNote>> notes = new TreeMap<Integer, Set<MusicNote>>(model.getNotes());
    if (model.getLowPitch() == null || model.getHighPitch() == null) {
      return;
    }
    Pitch lowPitch = model.getLowPitch();
    Pitch highPitch = model.getHighPitch();

    int maxBeat = notes.lastKey();
    while (maxBeat % 4 != 0) {
      maxBeat++;
    }

    graphics2D.setFont(new Font(Font.SANS_SERIF, Font.BOLD, NOTE_DIMENSION));
    graphics2D.setStroke(new BasicStroke(2));
    for (int i = 0; i < maxBeat + 1; i += 4) {
      graphics2D.drawString(String.valueOf(i), NOTE_DIMENSION * i + X_OFFSET, 10 + Y_OFFSET);
    }

    int pitchDifference = lowPitch.getDifference(highPitch);
    Pitch currentPitch = lowPitch;
    for (Integer i : notes.keySet()) {
      Set<MusicNote> notesToDraw = notes.get(i);
      for (int j = pitchDifference; j >= 0; j--) {
        for (MusicNote n : notesToDraw) {
          if (n.getPitch().compareTo(currentPitch) == 0) {
            if (n.getStartBeat() == i) {
              g.setColor(Color.BLACK);
            }
            else {
              g.setColor(Color.GREEN);
            }

            g.fillRect(NOTE_DIMENSION * i + X_OFFSET,
                    j * NOTE_DIMENSION + NOTE_DIMENSION + Y_OFFSET,
                    NOTE_DIMENSION, NOTE_DIMENSION);
          }
        }

        if (j != 0) {
          currentPitch = currentPitch.nextPitch();
        }
      }
      currentPitch = lowPitch;
    }

    currentPitch = lowPitch;
    g.setColor(Color.BLACK);
    for (int i = pitchDifference; i >= 0; i--) {
      g.drawString(currentPitch.toString(), 10, i * NOTE_DIMENSION + NOTE_DIMENSION * 2
              +
              Y_OFFSET);
      for (int j = 0; j < Math.ceil(notes.lastKey() / 4.0); j++) {
        g.drawRect(NOTE_DIMENSION  * j * 4 + X_OFFSET, i * NOTE_DIMENSION + NOTE_DIMENSION
                +
                Y_OFFSET, NOTE_DIMENSION * 4, NOTE_DIMENSION);
      }

      if (i != 0) {
        currentPitch = currentPitch.nextPitch();
      }
    }

    g.setColor(Color.RED);
    g.drawLine(currentBeat * NOTE_DIMENSION + X_OFFSET, NOTE_DIMENSION + Y_OFFSET,
            currentBeat * NOTE_DIMENSION + X_OFFSET,
            (pitchDifference + 2) * NOTE_DIMENSION + Y_OFFSET);

  }
}
