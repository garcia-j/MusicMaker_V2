package cs3500.music.view;

/**
 * Interface for a GUI Panels. Allows a GUI Panel to update its model and current beat.
 * Parameterized across the Music Editor model.
 */
public interface IGuiPanel<T> {

  /**
   * Updates the model and the current beat in the Panel.
   *
   * @param model The model to update to
   * @param currentBeat The currentBeat to update to
   */
  void updateValues(T model, int currentBeat);
}
