package cs3500.music.view;

/**
 * Factory class for views. Creates the specific view needed based on a String inputted by the user.
 */
public class ViewFactory {

  /**
   * Creates a specific view type based on the String argument. "console" for ConsoleView, "visual"
   * for GuiViewFrame, and "midi" for MidiViewImpl.
   *
   * @param viewType The type of view to create
   * @return The correct view type
   * @throws IllegalArgumentException If an incorrect view type was entered
   */
  public IView createView(String viewType) throws IllegalArgumentException {
    switch (viewType) {
      case "console":
        return new ConsoleView();
      case "visual":
        return new GuiViewFrame();
      case "midi":
        return new MidiViewImpl();
      default:
        throw new IllegalArgumentException("Illegal view type");
    }
  }
}
