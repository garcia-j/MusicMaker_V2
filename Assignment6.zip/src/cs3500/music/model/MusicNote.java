package cs3500.music.model;

import java.util.Objects;

/**
 * To represent a musical note. A musical note consists of a Pitch, a duration, and a start beat.
 */
public final class MusicNote {

  /**
   * The pitch of the note.
   *
   * <p>Class invariant: The pitch of the note always has a NoteName from C to B and an octave from
   * </p>
   */
  private final Pitch pitch;

  /**
   * The duration of the note.
   *
   * <p>Class invariant: The duration of the note is always positive.</p>
   */
  private final int duration;

  /**
   * The beat that this note starts at.
   *
   * <p>Class invariant: The beat of the note is always a natural number.</p>
   */
  private final int startBeat;

  /**
   * The instrument in the sound bank that this instrument represents.
   */
  private final int instrument;

  /**
   * The volume of the note when played via Midi.
   */
  private final int volume;

  /**
   * Constructor for MusicNote.
   *
   * @param pitch The pitch of the note
   * @param duration The duration of the note
   * @param startBeat The beat that this note starts at
   * @throws IllegalArgumentException If the duration is less than 1 or the startBeat is negative
   */
  public MusicNote(Pitch pitch, int duration, int startBeat, int instrument, int volume)
          throws IllegalArgumentException {
    if (duration < 0) {
      throw new IllegalArgumentException("Duration cannot be negative");
    }

    if (startBeat < 0) {
      throw new IllegalArgumentException("Start beat cannot be negative");
    }
    this.instrument = instrument;
    this.volume = volume;
    this.pitch = pitch;
    this.duration = duration;
    this.startBeat = startBeat;
  }

  /**
   * Copy Constructor for MusicNote.
   *
   * @param note The MusicNote to copy
   */
  MusicNote(MusicNote note) {
    this.pitch = note.pitch;
    this.duration = note.duration;
    this.startBeat = note.startBeat;
    this.instrument = note.instrument;
    this.volume = note.volume;
  }

  /**
   * Gets the instrument of the note.
   *
   * @return The instrument
   */
  public int getInstrument() {
    return this.instrument;
  }

  /**
   * Gets the volume of the note.
   *
   * @return The volume
   */
  public int getVolume() {
    return this.volume;
  }

  /**
   * Gets the Pitch of this note.
   * @return The pitch of this note
   */
  public Pitch getPitch() {
    return new Pitch(pitch);
  }

  /**
   * Gets the duration of this note.
   * @return The duration of this note
   */
  public int getDuration() {
    return duration;
  }

  /**
   * Gets the start beat of this note.
   * @return The start beat of this note
   */
  public int getStartBeat() {
    return startBeat;
  }

  /**
   * Determines if this note is equal to the given object. They are equal if they have the same
   * pitch, duration, and start beat.
   * @param o The object to compare to
   * @return If this note is equal to that object
   */
  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }

    if (! (o instanceof MusicNote)) {
      return false;
    }

    MusicNote that = (MusicNote)o;
    return this.pitch.equals(that.pitch)
            &&
            this.duration == that.duration
            &&
            this.startBeat == that.startBeat
            &&
            this.volume == that.volume
            &&
            this.instrument == that.instrument;
  }

  /**
   * Hash function for music note.
   * @return The hashcode of this note
   */
  @Override
  public int hashCode() {
    return Objects.hash(pitch, duration, startBeat, volume, instrument);
  }
}
